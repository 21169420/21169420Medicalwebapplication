</main>

<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted"><?php echo date('j F, Y h:i:s A')?></span>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"
></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
></script>

<script>
    $('input').attr('required',true);
</script>

</body>
</html>
